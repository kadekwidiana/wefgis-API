@extends('frontpage.layouts.main')

@section('content')
    <!-- Content -->
    <div class="content">
        <div id="map">
        </div>
    </div>
@endsection
