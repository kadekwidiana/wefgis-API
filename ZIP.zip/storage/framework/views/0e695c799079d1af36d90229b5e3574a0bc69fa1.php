

<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="content">
        <div id="map">

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontpage.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Widi\APP_RESEARCH\Web_GIS\resources\views/frontpage/maps.blade.php ENDPATH**/ ?>